import init from './init.js';

init();