export default function Error404(props) {
    return `<h1>404 ERROR</h1>`;
}