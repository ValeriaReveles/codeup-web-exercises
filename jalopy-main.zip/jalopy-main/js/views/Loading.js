export default function Loading(props) {
    return `<h1>Loading...</h1>`;
}