# Jalopy

Jalopy is a tiny (toy) SPA framework for Codeup Webdev v3 students.
